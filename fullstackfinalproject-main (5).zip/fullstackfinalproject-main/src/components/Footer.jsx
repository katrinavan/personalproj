import React from "react"

const Footer = () => {
    return (
      <div>
        <div className="h-100">

        </div>
        <footer className="footer footer-center p-4 bg-base-300 text-base-content mt-100">
          <aside>
            <p>Copyright © 2023 Berkeley Blog. All rights reserved.</p>
          </aside>
        </footer>
      </div>
    );
};
export default Footer;